import { Meteor } from 'meteor/meteor';
import { Emergencies } from '../imports/api/emergenciesCollection.js';
import { Markers } from '../imports/api/marker.js';
Meteor.startup(() => {
  // code to run on server at startup
});
