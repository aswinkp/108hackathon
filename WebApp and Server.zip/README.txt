108 EMERGENCY APPLICATION
=========================

The application is done in NodeJS framework called meteor js.

INSTALLATION INSTRUCTIONS

Linux/Mac OSX mandatory
1.In the terminal type
   curl https://install.meteor.com/ | sh

2.Now navigae inside my folder and just type 

   meteor npm install

   meteor

3.Now localserver would be opening in http://localhost:3000

If there is any problem to setup, you can view the screenshots that are inside the screeshots folder.


Screenshot Details/ Functionality Explanation.

Screen 1 Login Screen

The login screen will be the default page.

Screen 2 View Screen

When a user called for the emergency in the mobile application, the entry is added automatically on the left handed pane. WHen clicking on the view button, in the left
pane, map opens with the popup of where the user is. 

You can see the coloured screen in the left pane. Red represents Fire Station. Blue represents Ambulance. Yellow represents the Police Emergency.

Screen 3 Edit Screen

The call center personnel can change any of the data to provide updated status of the emergency (for example, the number of casualities may go up so the call center personnel can update the data).

Screen 4 Add Emergency

If the user does not have the internet connectivity, the call center personnel can now add directly through the Add Emergency button.


