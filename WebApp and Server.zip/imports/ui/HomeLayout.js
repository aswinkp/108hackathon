import { Template } from 'meteor/templating';

import './HomeLayout.html';
