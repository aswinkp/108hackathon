import { Meteor } from 'meteor/meteor';
import { Template } from 'meteor/templating';

import './HomeLayout.js';
import './MainLayout.js';

import './map.js';